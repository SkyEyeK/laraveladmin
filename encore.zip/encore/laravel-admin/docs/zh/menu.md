# 左侧边栏配置

打开`http://localhost:8000/admin/auth/menu`设置左侧边栏菜单。

树状菜单基于[Nestable](https://github.com/dbushell/Nestable)开发，通过拖动来调整菜单的结构和顺序，点击下面的保存按钮来保存设置，然后刷新就能看到左侧边栏的变化了,`路径`填写访问路径，角色选择可以看见这个菜单项的角色身份。
