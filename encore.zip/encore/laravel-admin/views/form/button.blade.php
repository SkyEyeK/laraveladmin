<div class="form-group">

    <label class="col-sm-{{$width['label']}} control-label"></label>

    <div class="col-sm-{{$width['field']}}">
        <input type='button' value='{{$label}}' class="btn {{ $class }}" {!! $attributes !!} />
    </div>
</div>