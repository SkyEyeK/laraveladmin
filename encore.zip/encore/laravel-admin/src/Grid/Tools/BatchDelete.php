<?php

namespace Encore\Admin\Grid\Tools;

class BatchDelete extends BatchAction
{

    protected  $batchResource;
    public function setBatchResource($batchResource){
        echo $this->batchResource;
        $this->batchResource = $batchResource;
    }
    /**
     * Script of batch delete action.
     */
    public function script()
    {
        $confirm = trans('admin::lang.delete_confirm');

        return <<<EOT

$('{$this->getElementClass()}').on('click', function() {

    if(confirm("{$confirm}")) {
        $.ajax({
            method: 'post',
            url: '/{$this->batchResource}/' + selectedRows().join(),
            data: {
                _method:'delete',
                _token:'{$this->getToken()}'
            },
            success: function (data) {
                $.pjax.reload('#pjax-container');

                if (typeof data === 'object') {
                    if (data.status) {
                        toastr.success(data.message);
                    } else {
                        toastr.error(data.message);
                    }
                }
            }
        });
    }
});

EOT;
    }
}
